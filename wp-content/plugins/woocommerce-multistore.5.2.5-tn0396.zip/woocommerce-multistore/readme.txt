=== WooMultistore ===
Tags: e-commerce, store, sales, sell, woo, shop, cart, checkout, downloadable, downloads, payments, paypal, storefront, stripe, woo commerce
Requires at least: 5.3.0
Tested up to: 6.4.2
Requires PHP: 7.4
Stable tag: 5.2.5
WC requires at least: 3.6.0
WC tested up to: 8.4.0