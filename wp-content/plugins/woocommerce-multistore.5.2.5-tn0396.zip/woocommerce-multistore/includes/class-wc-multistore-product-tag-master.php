<?php
/**
 * Product Tag Master Handler
 *
 * This handles product tag master related functionality.
 *
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WC_Multistore_Product_Tag_Master
 */
class WC_Multistore_Product_Tag_Master extends WC_Multistore_Abstract_Term_Master {

}