<?php
/**
 * Simple Master Product Handler
 *
 * This handles simple master product related functionality.
 *
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WC_Multistore_Product_Simple_Master
 */
class WC_Multistore_Product_Simple_Master extends WC_Multistore_Abstract_Product_Master{

}