<?php
/**
 * Master Image Handler
 *
 * This handles master image related functionality.
 *
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WC_Multistore_Image_Master
 */
class WC_Multistore_Image_Master extends  WC_Multistore_Abstract_Attachment_Master {

}