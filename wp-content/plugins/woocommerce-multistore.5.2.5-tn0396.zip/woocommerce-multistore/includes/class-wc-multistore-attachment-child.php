<?php
/**
 * Child Attachment Handler
 *
 * This handles child attachment related functionality.
 *
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WC_Multistore_Attachment_Child
 */
class WC_Multistore_Attachment_Child extends  WC_Multistore_Abstract_Attachment_Child {

}