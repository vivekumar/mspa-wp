<?php
/**
 * Product Review Master Handler
 *
 * This handles product review master related functionality.
 *
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WC_Multistore_Product_Review_Master
 */
class WC_Multistore_Product_Review_Master extends WC_Multistore_Abstract_Comment_Master {

}