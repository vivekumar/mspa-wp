<?php
/**
 * Product Tag Child Handler
 *
 * This handles product tag child related functionality.
 *
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WC_Multistore_Product_Tag_Child
 */
class WC_Multistore_Product_Tag_Child extends WC_Multistore_Abstract_Term_Child {

}