<?php
/**
 * Child Order Handler
 *
 * This handles child order related functionality.
 *
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WC_Multistore_Order_Child
 */
class WC_Multistore_Order_Child extends WC_Multistore_Abstract_Order_Child {

}