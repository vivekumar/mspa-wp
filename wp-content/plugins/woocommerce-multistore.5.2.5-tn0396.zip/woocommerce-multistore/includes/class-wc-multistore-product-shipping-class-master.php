<?php
/**
 * Shipping Class Master Handler
 *
 * This handles product shipping class master related functionality.
 *
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WC_Multistore_Product_Shipping_Class_Master
 */
class WC_Multistore_Product_Shipping_Class_Master extends WC_Multistore_Abstract_Term_Master {

}