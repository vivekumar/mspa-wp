<?php
/**
 * Master Attachment Handler
 *
 * This handles master attachment related functionality.
 *
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WC_Multistore_Attachment_Master
 */
class WC_Multistore_Attachment_Master extends  WC_Multistore_Abstract_Attachment_Master {

}