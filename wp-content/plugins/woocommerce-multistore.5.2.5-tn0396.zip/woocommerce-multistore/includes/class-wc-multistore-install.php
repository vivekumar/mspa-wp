<?php
/**
 * Install handler.
 *
 * This handles plugin install related functionality.
 *
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WC_Multistore_Install
 */
class WC_Multistore_Install {
	/**
	 * Install
	 **/
	public static function install() {

	}

}
