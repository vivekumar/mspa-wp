<?php
/**
 * Shipping Class Child Handler
 *
 * This handles product shipping class child related functionality.
 *
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WC_Multistore_Product_Shipping_Class_Child
 */
class WC_Multistore_Product_Shipping_Class_Child extends WC_Multistore_Abstract_Term_Child {

}