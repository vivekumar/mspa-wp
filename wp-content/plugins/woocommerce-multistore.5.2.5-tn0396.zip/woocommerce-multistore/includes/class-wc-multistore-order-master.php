<?php
/**
 * Master Order Handler
 *
 * This handles master order related functionality.
 *
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WC_Multistore_Order_Master
 */
class WC_Multistore_Order_Master extends WC_Multistore_Abstract_Order_Master {

}