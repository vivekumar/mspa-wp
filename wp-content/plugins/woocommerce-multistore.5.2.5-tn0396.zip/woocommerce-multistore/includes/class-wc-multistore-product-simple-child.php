<?php
/**
 * Simple Child Product Handler
 *
 * This handles simple child product related functionality.
 *
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WC_Multistore_Product_Simple_Child
 */
class WC_Multistore_Product_Simple_Child extends WC_Multistore_Abstract_Product_Child {



}