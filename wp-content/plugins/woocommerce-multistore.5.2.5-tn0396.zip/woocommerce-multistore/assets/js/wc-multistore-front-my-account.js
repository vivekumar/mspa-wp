;( function ( $, window, document, undefined ) {
	$( function() {
		$('#woo_mstore_accordion').accordion();
	} );
} )( jQuery, window, document );
